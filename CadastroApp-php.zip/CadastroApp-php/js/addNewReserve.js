var reserve = JSON.parse(localStorage.getItem('list_reserve')) || [];

function addReserve() {
    var inputProf = document.getElementById('professor').value;
    var inputHorario = document.getElementById('horario').value;
    var inputTurma = document.getElementById('turma').value;
    var inputSala = document.getElementById('sala').value;
    var inputData = document.getElementById('datepicker').value;
    var inputDescricao = document.getElementById('descricao').value;

    if (inputProf != null && inputHorario != null && inputTurma != null && inputSala != null && inputData != null && inputDescricao != null) {
        //JSON
        var obj = {
            prof: inputProf,
            horario: inputHorario,
            turma: inputTurma,
            sala: inputSala,
            data: inputData,
            descricao: inputDescricao
        }
        reserve.push(obj);
        addJson();
        //Valores nulos
        //Enviar pagina window.location = ../index.php
    } else {
        //Aparecer mensagem embaixo do input
        function erro() {

        }
    }
}

function addJson() {
    localStorage.setItem('list_reserve', JSON.stringify(reserve));
}