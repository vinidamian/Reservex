<?php require_once ('../session.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../css/fontawesome/css/all.css">
    <link rel="stylesheet" href="../css/addNewReserve.css">
    <link rel="shortcut icon" href="../img/logo.png"/>
    <title>RESERVA</title>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
    <script src="./js/addNewReserve.js"></script>

</head>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content"
            aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <a class="navbar-brand text-white" href="./indexInternal.php">Reservex&nbsp;<i class="fas fa-desktop text-white"></i></a>
    <!-- Links -->
    <div class="collapse navbar-collapse justify-content-end" id="nav-content">
        <ul class="navbar-nav">
            <li class="nav-item">
            </li>
        </ul>
    </div>
</nav>
<!-- Fim da navbar -->
<div class="card mt-4 ml-5 mr-5">
    <div class="card-header"><b>Nova reserva</b></div>
    <div class="card-body">
        <div class="container">
            <div class="row">
                <div class="col-sm">
                    <div class="form-group">
                        <p class="ml-3">Professor(a):</p>
                        <input type="text" id="professor" placeholder="Professor responsável" class="form-control col-md-10 ml-3">
                    </div>
                    <div class="form-group ">
                        <p class="ml-3">Horário:</p>
                        <select id="horario" class="form-control col-md-10 ml-3 mt">
                            <option >Horário</option>
                            <option>9:05-10:05</option>
                            <option>10:05-11:05</option>
                            <option>11:05-12:05</option>
                            <option>12:05-12:40</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="form-group ">
                        <p class="ml-3">Turma:</p>
                        <select id="turma" class="form-control col-md-10 ml-3 mt">
                            <option>Escolha uma turma</option>
                            <option>1A</option>
                            <option>1B</option>
                            <option>1C</option>
                            <option>2A</option>
                            <option>2B</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group ">
                        <p class="ml-3">Sala:</p>
                        <select id="sala" class="form-control col-md-10 ml-3 mt">
                            <option>Escolha a sala</option>
                            <option>520</option>
                            <option>303</option>
                            <option>Auditório</option>
                            <option>Quadra</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm">
                    <p class="">Data:</p>
                    <input class="form-control" placeholder="Data" id="datepicker" width="276" />
                    <script>
                        $('#datepicker').datepicker({
                            uiLibrary: 'bootstrap4'
                        });
                    </script>
                </div>
            </div>
            <div class="form-group ml-3">
                Descrição da aula:
                <textarea id="descricao" class="form-control col-sm-8 mt-2" id="exampleFormControlTextarea1" rows="4" maxlength="500"></textarea>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <a href="../internal/indexInternal.php" class="btn btn-secondary float-right">Voltar</a>
        <a href="#" class="btn btn-success">Salvar</a>
    </div>
</div>
<!-- Footer -->
<footer class="align-bottom fixed-bottom font-small bg-dark text-white">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3"> 2019 © Copyright -
        <a href="#" class="text-white">Reservex</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
</body>
</html>