<?php require_once ('../session.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../css/indexInternal.css">
    <link rel="stylesheet" href="../css/fontawesome/css/all.css">
    <link rel="shortcut icon" href="../img/logo.png"/>
    <script src='../js/indexInternal.js'></script>
    <link href='../fullcalendar/packages/core/main.css' rel='stylesheet' />
    <link href='../fullcalendar/packages/daygrid/main.css' rel='stylesheet' />
    <script src='../fullcalendar/packages/core/main.js'></script>
    <script src='../fullcalendar/packages/daygrid/main.js'></script>
    <title>RESERVA</title>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content"
            aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <a class="navbar-brand text-white" href="   indexInternal.php">Reservex&nbsp;<i class="fas fa-desktop text-white"></i></a>
    <!-- Links -->
    <div class="collapse navbar-collapse justify-content-end" id="nav-content">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="../root/companys.php" class="btn text-warning"><i class="far fa-address-card"></i></a>
                <a href="../internal/admin.php" class="btn text-white"><i class="fas fa-building"></i></a>
                <a href="../internal/account.php" class="btn text-white"><i class="fas fa-users-cog"></i></a>
                <a href="../index.php" class="btn text-white"><i class="fas fa-sign-out-alt"></i></a>
                <a href="../internal/addNewReserve.php" class="btn btn-success text-white"><i class="fas fa-plus"></i></a>
            </li>
        </ul>
    </div>
</nav>
<!-- Fim da navbar -->
<!--tabela-->
<div class="card mt-4 ml-5 mr-5">
    <div class="card-header"><b>Salas alocadas</b></div>
    <div class="card-body">
        <div class="form-row">
            <div class="input-group mb-3">
                <input type="text" class="form-control col-md-4 ml-5 mr-0 border-secondary" placeholder="Buscar" aria-label="Buscar" aria-describedby="Buscar">
                <div class="input-group-append">
                    <button class="btn btn-light border-left-0 border-secondary" type="button" id="icon"><i class="fas fa-search"></i></button>
                </div>
                <input type="submit" onclick="ocultarExibirCalendario()" class="col-md-1 ml-1" value="Calendario">
                <input type="submit" onclick="ocultarExibirLista()" class="col-md-1 ml-1" value="Lista">
            </div>
        </div>
<hr>
        <h2 class="ml-5 text-dark">Reservas</h2>
<table id="hideLista" class="table table-bordered table-light mt-2  ml-5 col-md-11 mr-1 table-striped text-center">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">Sala</th>
      <th scope="col">Professor(a)</th>
      <th scope="col">Turma</th>
      <th scope="col">Data</th>
      <th scope="col">Horário</th>
      <th scope="col">Ações</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"><input type="checkbox" aria-label="Excluir"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td><button class="btn btn-outline-light"><i class="fas fa-trash text-danger"></i></button></td>
    </tr>
    <tr>
      <th scope="row"><input type="checkbox" aria-label="Excluir"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td><button class="btn btn-outline-light"><i class="fas fa-trash text-danger"></i></button></td>
    </tr>
    <tr>
      <th scope="row"><input type="checkbox" aria-label="Excluir"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td><button class="btn btn-outline-light"><i class="fas fa-trash text-danger"></i></button></td>
    </tr>
  </tbody>
</table>
    </div>


<!--CALENDARIO-->
    <div id="hideCalendar" class="form-group col-md-6">
    <div id='calendar' class="col-md-12"></div>
    </div>



</div>
<!-- Footer -->
<footer class="align-bottom fixed-bottom font-small bg-dark text-white">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3"> 2019 © Copyright -
        <a href="#" class="text-white">Reservex</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
</body>
</html>