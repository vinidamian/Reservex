<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../css/fontawesome/css/all.css">
    <link rel="shortcut icon" href="../img/logo.png"/>
    <title>RESERVA</title>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content"
            aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <a class="navbar-brand text-white" href="index.php">Reservex&nbsp;<i class="fas fa-desktop text-white"></i></a>
    <!-- Links -->
    <div class="collapse navbar-collapse justify-content-end" id="nav-content">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="../internal/addNewReserve.php" class="btn btn-success text-white"><i class="fas fa-plus"></i></a>
            </li>
        </ul>
    </div>
</nav>
<!-- Fim da navbar -->
<!--tabela-->
<div class="card mt-4 ml-5 mr-5">
    <div class="card-header"><b>Instituição</b></div>
    <div class="card-body">
            <div class="container">
                    <div class="row col-md-12">
                    <table class="table table-bordered table-light">
                            <thead>
                              <tr>
                                <th scope="col">Horário</th>
                                <th scope="col">Segunda</th>
                                <th scope="col">Terça</th>
                                <th scope="col">Quarta</th>
                                <th scope="col">Quinta</th>
                                <th scope="col">Sexta</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <th scope="row">07:25-08:15</th>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                              </tr>
                              <tr>
                                <th scope="row">08:15-09:05</th>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                              </tr>
                              <tr>
                                <th scope="row">09:05-09:55</th>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                              </tr>
                              <tr>
                              <th scope="row">-</th>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                              </tr>
                              <tr>
                              <th scope="row">10:10-11:05</th>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                              </tr>
                              <tr>
                              <th scope="row">11:05-11:55</th>
                                <td></td>
                                <td> </td>
                                <td></td>
                                <td></td>
                                <td></td>
                              </tr>
                              <tr>
                              <th scope="row">11:55-12:40</th>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                              </tr>
                            </tbody>
                          </table>
                          <hr class="">
            <div class="container col-md-12">
                    <div class="row col-md-12 ">
                        <div class="col-sm col-md-7">
                            <b >Equipe</b>
                            <table class="table table-light table-stripped table-borderless text-center mt-4 col-md-6">
                                <tbody>
                                    <tr>
                                        <td class="bg-grey">Dísciplina</td>
                                        <td class="bg-grey">Professor</td>
                                    </tr>
    
                                    <tr>
                                        <td>Geografia</td>
                                        <td>Otto</td>
                                    </tr>
                                    <tr>
                                        <td>Matemática</td>
                                        <td>Jacob</td>
                                    </tr>
                                    <tr>
                                        <td>Química</td>
                                        <td>Larry</td>
                                    </tr>
                                </tbody>
                            
                            </table>
                        <tfoot class="ml-3"><button class="btn btn-primary">Adicionar Professor</button></tfoot>
                        </div>
                        <!-- SEGUNDA FILEIRA-->
                        <div class="col-sm col-md-5">
                                <b class="">Salas</b>
                                <table class="table table-light table-stripped table-borderless mt-4 col-md-6 text-center">
                                    <tbody>
                                        <tr>
                                            <td class="bg-grey">Bloco</td>
                                            <td class="bg-grey">Número da sala</td>
                                        </tr>
        
                                        <tr>
                                            <td>1</td>
                                            <td>104</td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                            <td>520</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>305</td>
                                        </tr>
                                    </tbody>
                                
                                </table>
                            <tfoot class="ml-3"><button class="btn btn-primary">Adicionar Sala</button></tfoot>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
            <a href="../internal/index.php" class="btn btn-secondary float-right">Voltar</a>
            <a href="#" class="btn btn-success">Salvar</a>
        </div>
</div>
<!-- Footer -->
<footer class="align-bottom fixed-bottom font-small bg-dark text-white">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3"> 2019 © Copyright -
        <a href="#" class="text-white">Reservex</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
</body>
</html>